import https from "node:https";

const BASE = () => process.env.PAYBETA_BASE_URL || "https://api.sandbox.paybeta.ng";
const key = () => process.env.PAYBETA_SECRET_KEY;
const headers = { "content-type": "application/json", "cache-control": "no-store" };

function paybetaGetWithJson(path, body) {
  return new Promise((resolve, reject) => {
    if (!key()) return reject(new Error("Paybeta server key is not configured."));
    const target = new URL(path, BASE());
    const payload = JSON.stringify(body);
    const request = https.request(target, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "P-API-KEY": key(),
        "Content-Length": Buffer.byteLength(payload)
      }
    }, response => {
      let raw = "";
      response.setEncoding("utf8");
      response.on("data", chunk => raw += chunk);
      response.on("end", () => {
        let data = {};
        try { data = JSON.parse(raw); } catch {}
        if (response.statusCode < 200 || response.statusCode >= 300) {
          const error = new Error(data.message || `Paybeta request failed (${response.statusCode})`);
          error.status = response.statusCode;
          return reject(error);
        }
        resolve(data);
      });
    });
    request.on("error", reject);
    request.write(payload);
    request.end();
  });
}

async function paybetaGet(path) {
  if (!key()) throw new Error("Paybeta server key is not configured.");
  const response = await fetch(`${BASE()}${path}`, {
    headers: { "Accept": "application/json", "P-API-KEY": key() }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.message || `Paybeta request failed (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}

export default async (req) => {
  const url = new URL(req.url);
  try {
    if (req.method === "GET" && url.pathname.endsWith("/providers")) {
      return Response.json(await paybetaGet("/v2/data-bundle/providers"), { headers });
    }
    if (req.method === "GET" && url.pathname.endsWith("/plans")) {
      const service = url.searchParams.get("service");
      const allowed = ["mtn_data", "airtel_data", "glo_data", "9mobile_data"];
      if (!allowed.includes(service)) {
        return Response.json({ error: "Choose a valid data network." }, { status: 400, headers });
      }
      return Response.json(await paybetaGetWithJson("/v2/data-bundle/list", { service }), { headers });
    }
    return Response.json({ error: "Not found" }, { status: 404, headers });
  } catch (error) {
    return Response.json({ error: error.message }, { status: error.status || 500, headers });
  }
};

export const config = { path: "/api/paybeta/*" };
