MA GODE DATA — Netlify + Paybeta starter

WHAT THIS PACKAGE DOES
- Publishes the storefront in /public.
- Uses a Netlify Function as a server-side proxy to Paybeta.
- Loads providers and data bundles without exposing the Paybeta secret key.
- Does NOT yet take customer payments or trigger data purchases. That is intentionally disabled until payment verification, order storage/idempotency and Paybeta purchase payload are implemented and tested.

1) Deploy
- Create a new GitHub repository and upload the contents of this ZIP (not the ZIP itself).
- In Netlify: Add new site > Import an existing project > choose the repository.
- Build settings: publish directory public; functions directory netlify/functions. netlify.toml already sets these.

2) Add Netlify environment variables
Netlify dashboard > your site > Project configuration > Environment variables.
Add:
PAYBETA_SECRET_KEY = your Paybeta SECRET KEY (never paste it into HTML or GitHub)
PAYBETA_BASE_URL = https://api.sandbox.paybeta.ng

Set variables for Functions/runtime scope if the UI asks. Redeploy after adding/changing variables.

3) Test
Open your deployed site. It should request plans through:
GET /.netlify/functions/paybeta/providers
GET /api/paybeta/plans?service=mtn_data
Also try airtel_data, glo_data, 9mobile_data.

4) Before live launch
- Ask Paybeta to activate API access and confirm the exact data-plan response fields and purchase request body for each network.
- Confirm sandbox account and test successful, pending, failed, duplicate and timeout cases.
- Add Paystack payment initialization and server-side verification. Do not fulfil an order based only on the browser redirect.
- Store orders in a database, use unique references/idempotency, and only call Paybeta after verified payment.
- Add webhook signature verification using Paybeta's documented HMAC-SHA256 scheme.
- Switch to https://api.paybeta.ng only after Paybeta approves production/live mode.
- Rotate any secret key previously exposed in chat or screenshots.

SECURITY
Never put Paybeta secret key or Paystack secret key in public HTML, JavaScript, GitHub, screenshots or chat. Store them as Netlify environment variables. Public keys may be used in browser only where the provider explicitly documents that.
